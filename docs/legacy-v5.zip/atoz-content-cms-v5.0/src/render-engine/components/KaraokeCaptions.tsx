import React from 'react';
import { useCurrentFrame, useVideoConfig } from 'remotion';

export interface CaptionLine { start: number; end: number; words: { text: string; start: number; end: number }[]; }

export const KaraokeCaptions: React.FC<{ captions: CaptionLine[] }> = ({ captions }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const time = frame / fps;
  if (!captions || captions.length === 0) return null;
  const line = captions.find((c) => time >= c.start && time <= c.end + 0.15);
  if (!line) return null;

  return (
    <div style={{ position: 'absolute', left: 52, right: 145, bottom: 345, display: 'flex', justifyContent: 'center', direction: 'rtl', zIndex: 12 }}>
      <div style={{ backgroundColor: 'rgba(10, 25, 49, 0.95)', border: '2px solid #FFB400', borderRadius: 20, padding: '12px 24px', display: 'inline-flex', gap: '8px', fontSize: 36, fontWeight: 900, color: '#FFFFFF' }}>
        {line.words.slice(0, 5).map((w, idx) => {
          const active = time >= w.start && time <= w.end;
          return (
            <span key={idx} style={{ padding: '3px 11px', borderRadius: 11, backgroundColor: active ? '#FFB400' : 'transparent', color: active ? '#0A0A0C' : '#FFFFFF' }}>{w.text}</span>
          );
        })}
      </div>
    </div>
  );
};
