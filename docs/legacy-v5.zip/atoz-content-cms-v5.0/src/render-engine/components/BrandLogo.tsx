import React, { useState } from 'react';
import { Img, staticFile } from 'remotion';
import brandConfig from '../../../public/brand-config.json';

export const BrandLogo: React.FC<{ sectionCode?: keyof typeof brandConfig.sectionThemes; isDark?: boolean; height?: number }> = ({
  sectionCode = 'Library',
  isDark = false,
  height = 44
}) => {
  const [imgFailed, setImgFailed] = useState(false);
  const theme = brandConfig.sectionThemes[sectionCode] || brandConfig.sectionThemes.Library;
  const srcPath = isDark ? brandConfig.parentAssets.persianHorizontalWhite : brandConfig.parentAssets.persianHorizontalColor;

  if (!imgFailed) {
    return <Img src={staticFile(srcPath)} onError={() => setImgFailed(true)} style={{ height, width: 'auto', display: 'block', objectFit: 'contain' }} />;
  }
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{ width: height, height, borderRadius: 12, backgroundColor: '#0A1931', color: '#FFB400', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 900, fontSize: Math.round(height * 0.48), border: '2px solid #FFB400' }}>AZ</div>
      <span style={{ fontWeight: 900, fontSize: Math.round(height * 0.58), color: isDark ? '#FFB400' : '#0A1931' }}>{theme.subbrandName}</span>
    </div>
  );
};
