import React from 'react';
export const FontLoader: React.FC = () => (
  <style>{`@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;700;800;900&display=swap'); * { font-family: 'Vazirmatn', Tahoma, sans-serif !important; }`}</style>
);
