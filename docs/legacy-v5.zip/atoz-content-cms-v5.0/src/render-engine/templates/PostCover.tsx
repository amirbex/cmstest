import React from 'react';
import { AbsoluteFill } from 'remotion';
import brandConfig from '../../../public/brand-config.json';
import { FontLoader } from '../components/FontLoader';
import { BrandLogo } from '../components/BrandLogo';

export const PostCover: React.FC<{ title: string; subtitle?: string; badge?: string; sectionCode?: keyof typeof brandConfig.sectionThemes }> = ({
  title, subtitle = 'تحلیل تخصصی صنعت غذا و نوشیدنی', badge = 'AtoZ.FnB', sectionCode = 'Magazine'
}) => {
  const theme = brandConfig.sectionThemes[sectionCode] || brandConfig.sectionThemes.Magazine;
  return (
    <AbsoluteFill style={{ backgroundColor: '#F8F6F0', color: '#0A1931', direction: 'rtl', padding: 84, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <FontLoader />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ backgroundColor: theme.accent, color: '#FFFFFF', padding: '12px 28px', borderRadius: 16, fontSize: 26, fontWeight: 800 }}>{badge}</span>
        <span dir="ltr" style={{ fontSize: 26, fontWeight: 700 }}>{brandConfig.handle}</span>
      </div>
      <div>
        <h1 style={{ fontSize: 64, fontWeight: 900, lineHeight: 1.3 }}>{title}</h1>
        <p style={{ fontSize: 34, color: '#475569', marginTop: 28 }}>{subtitle}</p>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <BrandLogo sectionCode={sectionCode} isDark={false} height={46} />
        <span style={{ backgroundColor: '#FFB400', color: '#0A0A0C', padding: '10px 24px', borderRadius: 14, fontWeight: 900, fontSize: 24 }}>مطالعه اسلایدها ←</span>
      </div>
    </AbsoluteFill>
  );
};
