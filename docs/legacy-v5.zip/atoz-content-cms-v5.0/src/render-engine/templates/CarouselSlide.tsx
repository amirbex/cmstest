import React from 'react';
import { AbsoluteFill } from 'remotion';
import brandConfig from '../../../public/brand-config.json';
import { FontLoader } from '../components/FontLoader';
import { BrandLogo } from '../components/BrandLogo';

export const CarouselSlide: React.FC<{ slideNumber: number; totalSlides: number; sectionCode?: keyof typeof brandConfig.sectionThemes; badge: string; heading: string; body: string; highlightMetric?: string }> = ({
  slideNumber, totalSlides, sectionCode = 'Library', badge, heading, body, highlightMetric
}) => {
  const theme = brandConfig.sectionThemes[sectionCode] || brandConfig.sectionThemes.Library;
  const isLight = slideNumber % 2 === 1;
  return (
    <AbsoluteFill style={{ backgroundColor: isLight ? '#F8F6F0' : '#0A1931', color: isLight ? '#0A1931' : '#FFFFFF', direction: 'rtl', padding: 76, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <FontLoader />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ backgroundColor: isLight ? theme.accent : '#FFB400', color: isLight ? '#FFFFFF' : '#0A0A0C', padding: '10px 26px', borderRadius: 14, fontSize: 25, fontWeight: 900 }}>{badge}</span>
        <span dir="ltr" style={{ fontSize: 28, fontWeight: 800 }}>{slideNumber} / {totalSlides}</span>
      </div>
      <div style={{ backgroundColor: isLight ? '#FFFFFF' : 'rgba(255,255,255,0.06)', borderRadius: 36, padding: 56 }}>
        <h2 style={{ fontSize: 48, fontWeight: 900, lineHeight: 1.35 }}>{heading}</h2>
        {highlightMetric && <div style={{ display: 'inline-block', border: '2px solid #FFB400', color: '#FFB400', padding: '12px 26px', borderRadius: 18, fontSize: 38, fontWeight: 900, margin: '24px 0' }}>{highlightMetric}</div>}
        <p style={{ fontSize: 33, lineHeight: 1.75 }}>{body}</p>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <BrandLogo sectionCode={sectionCode} isDark={!isLight} height={42} />
        <span dir="ltr" style={{ fontSize: 25, fontWeight: 700 }}>{brandConfig.handle}</span>
      </div>
    </AbsoluteFill>
  );
};
