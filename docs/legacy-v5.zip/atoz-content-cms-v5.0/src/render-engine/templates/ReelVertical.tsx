import React from 'react';
import { AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, useVideoConfig, spring } from 'remotion';
import brandConfig from '../../../public/brand-config.json';
import { KaraokeCaptions, CaptionLine } from '../components/KaraokeCaptions';
import { FontLoader } from '../components/FontLoader';
import { BrandLogo } from '../components/BrandLogo';

export interface ReelProps {
  title: string;
  subtitle?: string;
  sectionCode?: keyof typeof brandConfig.sectionThemes;
  logoMotion?: string;
  audioFile?: string;
  audioDurationSec?: number;
  enableSfx?: boolean;
  captions?: CaptionLine[];
  scenes: { id: number; eyebrow?: string; cardTitle: string; metric: string; metricCaption?: string; items?: string[]; chartData?: { label: string; value: number }[] }[];
  customLayout?: { logoX?: number; logoY?: number; titleY?: number; cardY?: number };
}

export const ReelVertical: React.FC<ReelProps> = ({
  title,
  subtitle,
  sectionCode = 'Library',
  logoMotion = 'kinetic-az',
  audioFile,
  enableSfx = true,
  captions = [],
  scenes,
  customLayout = {}
}) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const time = frame / fps;
  const theme = brandConfig.sectionThemes[sectionCode] || brandConfig.sectionThemes.Library;
  const isDark = theme.mode === 'dark';

  const outroFrames = logoMotion !== 'none' ? Math.round(2.5 * fps) : 0;
  const contentFrames = Math.max(fps * 4, durationInFrames - outroFrames);
  const isOutro = outroFrames > 0 && frame >= contentFrames;

  const contentSec = contentFrames / fps;
  const secPerScene = contentSec / Math.max(1, scenes.length);
  const framesPerScene = Math.round(secPerScene * fps);
  const currentSceneIndex = Math.min(Math.floor(time / secPerScene), Math.max(0, scenes.length - 1));
  const scene = scenes[currentSceneIndex] || { id: 1, cardTitle: title, metric: '100%', items: ['آماده تولید'] };
  const localFrame = Math.max(0, frame - currentSceneIndex * framesPerScene);
  const heroSpring = spring({ frame: localFrame, fps, config: { damping: 16, stiffness: 120 } });

  return (
    <AbsoluteFill style={{ backgroundColor: theme.bg, color: isDark ? '#F8FAFC' : '#0A1931', direction: 'rtl', paddingTop: 56, paddingLeft: 52, paddingRight: 145, paddingBottom: 340, overflow: 'hidden' }}>
      <FontLoader />
      {audioFile && <Audio src={staticFile(audioFile)} volume={1.0} />}
      {enableSfx && <Audio src={staticFile('sfx/ambient-bed.wav')} volume={audioFile ? 0.14 : 0.35} loop />}
      {enableSfx && scenes.map((_, idx) => <Sequence key={idx} from={idx * framesPerScene} durationInFrames={15}><Audio src={staticFile('sfx/whoosh.wav')} volume={0.25} /></Sequence>)}

      {isOutro ? (
        <AbsoluteFill style={{ backgroundColor: '#0A1931', color: '#FFFFFF', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 24, zIndex: 20 }}>
          <BrandLogo sectionCode={sectionCode} isDark={true} height={76} />
          <div style={{ fontSize: 32, fontWeight: 900, color: '#FFB400', textAlign: 'center', maxWidth: 780 }}>{brandConfig.promise}</div>
          <div dir="ltr" style={{ border: '2px solid #FFB400', padding: '12px 32px', borderRadius: 999, fontSize: 28, fontWeight: 900 }}>{brandConfig.domain}</div>
        </AbsoluteFill>
      ) : (
        <>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', transform: `translate(${customLayout.logoX || 0}px, ${customLayout.logoY || 0}px)` }}>
            <div style={{ backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : '#FFFFFF', padding: '8px 20px', borderRadius: 18 }}><BrandLogo sectionCode={sectionCode} isDark={isDark} height={40} /></div>
            <div style={{ backgroundColor: theme.accent, color: '#FFFFFF', padding: '9px 22px', borderRadius: 999, fontSize: 22, fontWeight: 800 }}>{theme.name}</div>
          </div>

          <div style={{ marginTop: 24 + (customLayout.titleY || 0), backgroundColor: isDark ? 'rgba(255,255,255,0.06)' : '#EAF2FE', borderRadius: 24, padding: '20px 26px', textAlign: 'center' }}>
            <h1 style={{ fontSize: 36, fontWeight: 900, lineHeight: 1.35, margin: 0 }}>{title}</h1>
            {subtitle && <p style={{ fontSize: 22, opacity: 0.82, marginTop: 8, marginBottom: 0 }}>{subtitle}</p>}
          </div>

          <div style={{ marginTop: 24 + (customLayout.cardY || 0), transform: `scale(${0.92 + 0.08 * heroSpring})`, background: 'linear-gradient(135deg, #0A1931, #1e3a8a)', borderRadius: 26, padding: '24px 30px', color: '#FFFFFF', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 16 }}>
            <div>
              <span style={{ backgroundColor: '#FFB400', color: '#0A0A0C', padding: '5px 14px', borderRadius: 999, fontSize: 19, fontWeight: 900 }}>{scene.eyebrow || `گام ${currentSceneIndex + 1}`}</span>
              <div style={{ fontSize: 30, fontWeight: 900, marginTop: 10 }}>{scene.cardTitle}</div>
            </div>
            <div dir="ltr" style={{ fontSize: 42, fontWeight: 900, color: '#FFB400', backgroundColor: 'rgba(255,255,255,0.08)', padding: '12px 20px', borderRadius: 20 }}>{scene.metric}</div>
          </div>

          <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {(scene.items || []).slice(0, 3).map((item, idx) => (
              <div key={idx} style={{ minHeight: 90, borderRadius: 22, backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : '#FFFFFF', display: 'flex', alignItems: 'center', gap: 18, padding: '16px 22px' }}>
                <div style={{ width: 50, height: 50, borderRadius: 14, backgroundColor: idx === 1 ? '#FFB400' : theme.accent, color: idx === 1 ? '#0A0A0C' : '#FFFFFF', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, fontWeight: 900 }}>0{idx + 1}</div>
                <div style={{ fontSize: 28, fontWeight: 700, flex: 1 }}>{item}</div>
              </div>
            ))}
          </div>

          <KaraokeCaptions captions={captions} />
        </>
      )}
    </AbsoluteFill>
  );
};
