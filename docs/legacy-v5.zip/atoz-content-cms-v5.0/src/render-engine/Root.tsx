import React from 'react';
import { Composition, Still } from 'remotion';
import { ReelVertical } from './templates/ReelVertical';
import { CarouselSlide } from './templates/CarouselSlide';
import { PostCover } from './templates/PostCover';

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="ReelVertical"
      component={ReelVertical}
      durationInFrames={360}
      fps={30}
      width={1080}
      height={1920}
      defaultProps={{ title: 'AtoZ.FnB Content CMS', sectionCode: 'Library', scenes: [{ id: 1, cardTitle: 'سیستم‌سازی', metric: '100%', items: ['آماده تولید'] }] }}
      calculateMetadata={({ props }) => ({
        durationInFrames: props.audioDurationSec && props.audioDurationSec > 2 ? Math.ceil((props.audioDurationSec + 2.5) * 30) : 360
      })}
    />
    <Still id="PostCover" component={PostCover} width={1080} height={1350} defaultProps={{ title: 'AtoZ.FnB' }} />
    <Still id="CarouselSlide" component={CarouselSlide} width={1080} height={1350} defaultProps={{ slideNumber: 1, totalSlides: 4, badge: 'AtoZ', heading: 'عنوان', body: 'متن' }} />
  </>
);
