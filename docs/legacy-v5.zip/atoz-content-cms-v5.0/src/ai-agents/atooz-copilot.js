import { HIGH_CAPACITY_CHAIN, runAgentTask } from './model-router.js';
import { loadDb, approveBlueprintsForProduction } from '../core/relational-db.js';
import { expandIdeaIntoConcepts, generateMultiDeliverableBatch } from './orchestrator.js';
import { synthesizeHybridVoice } from './voice-engine.js';
import { sysLog } from '../core/logger.js';

export async function chatWithAtooz(userMessage, confirmedAction = null, speakReply = false) {
  sysLog('AGENT', 'آتوز (ATOOZ MCP)', `دریافت فرمان: "${userMessage}"`);
  const db = await loadDb();

  // Execute confirmed action
  if (confirmedAction && confirmedAction.action) {
    if (confirmedAction.action === 'CREATE_IDEA' && confirmedAction.ideaTopic) {
      sysLog('INFO', 'ATOOZ-Confirmed', `در حال ثبت و تولید ایده: "${confirmedAction.ideaTopic}"`);
      const expanded = await expandIdeaIntoConcepts({
        rawIdea: confirmedAction.ideaTopic,
        sectionCode: confirmedAction.sectionCode || 'Library',
        useWebSearch: false
      });
      const topConcept = expanded.concepts?.[0] || { angleTitle: confirmedAction.ideaTopic, summary: confirmedAction.ideaTopic };
      const records = await generateMultiDeliverableBatch({
        conceptTitle: topConcept.angleTitle,
        conceptSummary: topConcept.summary,
        sectionCode: confirmedAction.sectionCode || 'Library',
        counts: { article: 1, reels: 1, youtube: 0, carousels: 1, posts: 0 }
      });
      const reply = `تایید شد امیر جان! ایده «${topConcept.angleTitle}» ثبت شد و ۳ الگوی محتوایی (${records.map((r) => r.content_id).join('، ')}) ساخته و به لیست الگوهای در انتظار تایید اضافه شدند.`;
      let audioUrl = null;
      if (speakReply) {
        try {
          const v = await synthesizeHybridVoice({ scriptText: reply, engine: 'local-kokoro' });
          audioUrl = v.relativePath;
        } catch {}
      }
      return {
        reply,
        audioUrl,
        mcpToolCalled: 'mcp.content.create_idea_batch',
        action: 'OPEN_ROOM',
        targetRoom: 'ideation',
        createdRecords: records,
        requiresConfirmation: false
      };
    }

    if (confirmedAction.action === 'APPROVE_ALL_BLUEPRINTS') {
      const res = await approveBlueprintsForProduction({
        contentIds: db.contents.filter((c) => c.status === 'blueprint_pending').map((c) => c.content_id)
      });
      return {
        reply: `تایید شد امیر جان! ${res.approvedCount} الگو تایید شدند و به صف تولید منتقل گردیدند.`,
        mcpToolCalled: 'mcp.production.approve_blueprints',
        action: 'OPEN_ROOM',
        targetRoom: 'studio',
        requiresConfirmation: false
      };
    }

    return {
      reply: `فرمان شما اجرا شد امیر جان.`,
      mcpToolCalled: confirmedAction.mcpToolCalled || 'mcp.execute',
      action: confirmedAction.action,
      targetRoom: confirmedAction.targetRoom,
      targetContentId: confirmedAction.targetContentId,
      requiresConfirmation: false
    };
  }

  const dbSummary = {
    totalContents: db.contents.length,
    pendingBlueprints: db.contents.filter((c) => c.status === 'blueprint_pending').length,
    recentContents: db.contents.slice(0, 6).map((c) => ({
      content_id: c.content_id,
      title: c.title,
      status: c.status
    }))
  };

  const prompt = `
  ${db.systemPrompts.ATOOZ_CORE}
  داده‌های زنده سیستم:
  ${JSON.stringify(dbSummary, null, 2)}

  فرمان کاربر: "${userMessage}"

  خروجی را دقیقاً در قالب JSON معتبر زیر برگردان:
  {
    "reply": "پاسخ کوتاه، صمیمی، دقیق و اجرایی آتوز به فارسی",
    "mcpToolCalled": "نام ابزار MCP (مثلاً mcp.content.create_idea_batch | mcp.studio.open | mcp.calendar.status | mcp.production.approve)",
    "requiresConfirmation": true,
    "action": "NONE | CREATE_IDEA | APPROVE_ALL_BLUEPRINTS | OPEN_ROOM | MOVE_TO_EDIT",
    "ideaTopic": "اگر فرمان درباره ثبت ایده جدید است، موضوع دقیق ایده را بنویس وگرنه null",
    "sectionCode": "Library | Magazine | Calculators | AI | Solutions | Academy",
    "targetRoom": "command | puzzle3m | ideation | studio | gallery | publishing | data | prompts | pr | monitor",
    "targetContentId": "ATZ-C-000001 یا null"
  }`;

  const res = await runAgentTask('ATOOZ_CORE', HIGH_CAPACITY_CHAIN, () => ({
    contents: prompt,
    config: { responseMimeType: 'application/json' }
  }));

  const decision = JSON.parse(res.text);
  let audioUrl = null;
  if (speakReply) {
    try {
      const v = await synthesizeHybridVoice({ scriptText: decision.reply, engine: 'local-kokoro' });
      audioUrl = v.relativePath;
    } catch {}
  }

  return {
    ...decision,
    audioUrl
  };
}
