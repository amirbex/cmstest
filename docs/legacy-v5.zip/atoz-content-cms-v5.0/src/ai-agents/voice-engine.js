import { ai } from './model-router.js';
import { incrementPersistentQuota, loadDb } from '../core/relational-db.js';
import { sysLog } from '../core/logger.js';
import fs from 'fs/promises';
import fsSync from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);
const PYTHON_URL = process.env.PYTHON_ENGINE_URL || 'http://127.0.0.1:5005';

function buildChunkedCaptions(wordsList) {
  const chunks = [];
  const CHUNK_SIZE = 4;
  for (let i = 0; i < wordsList.length; i += CHUNK_SIZE) {
    const slice = wordsList.slice(i, i + CHUNK_SIZE);
    if (slice.length > 0) {
      chunks.push({ start: slice[0].start, end: slice[slice.length - 1].end, words: slice });
    }
  }
  return chunks;
}

function estimateWavDurationSec(buffer) {
  try {
    if (buffer.toString('ascii', 0, 4) === 'RIFF') {
      const byteRate = buffer.readUInt32LE(28);
      const dataSize = buffer.readUInt32LE(40);
      if (byteRate > 0 && dataSize > 0) return Number((dataSize / byteRate).toFixed(2));
    }
  } catch {}
  return Number((buffer.length / 48000).toFixed(2));
}

function buildHeuristicCaptions(scriptText, durationSec) {
  const words = scriptText.split(/\s+/).filter(Boolean);
  const secPerWord = durationSec / Math.max(1, words.length);
  const rawWords = words.map((w, idx) => ({
    text: w,
    start: Number((idx * secPerWord).toFixed(2)),
    end: Number(((idx + 1) * secPerWord).toFixed(2))
  }));
  return buildChunkedCaptions(rawWords);
}

async function synthesizeWindowsOfflineFallback(scriptText, outputPath) {
  const safeText = scriptText.replaceAll('"', ' ').replaceAll("'", ' ').replaceAll('\n', ' ');
  const normalizedOut = path.win32.normalize(outputPath);
  const psCmd = `Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.SetOutputToWaveFile('${normalizedOut}'); $s.Speak('${safeText}'); $s.Dispose()`;
  await execAsync(`powershell -NoProfile -Command "${psCmd}"`);
}

export async function synthesizeHybridVoice({ scriptText, engine = 'gemini', voiceSampleName = 'my-voice.wav' }) {
  const fileName = `voice-${engine}-${Date.now()}.wav`;
  const publicAudioDir = path.resolve('public/generated-audio');
  await fs.mkdir(publicAudioDir, { recursive: true });
  const publicAudioPath = path.join(publicAudioDir, fileName);

  sysLog('VOICE', 'رامتین • طراح صدا', `تولید صوت با موتور: ${engine}`);

  if (engine === 'local-kokoro' || engine === 'local-f5-clone') {
    try {
      const res = await fetch(`${PYTHON_URL}/tts`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(25000),
        body: JSON.stringify({
          text: scriptText,
          mode: engine,
          sample_path: path.resolve('public/voice-samples', voiceSampleName),
          output_path: publicAudioPath
        })
      });
      if (res.ok) {
        const data = await res.json();
        const rawWords = (data.captions || []).flatMap((c) => c.words || []);
        const dur = data.durationSec || 25;
        return {
          fileName,
          engineUsed: data.engine || engine,
          staticAudioPath: `generated-audio/${fileName}`,
          relativePath: `/public/generated-audio/${fileName}`,
          durationSec: dur,
          captions: rawWords.length > 0 ? buildChunkedCaptions(rawWords) : buildHeuristicCaptions(scriptText, dur)
        };
      }
    } catch {}

    await synthesizeWindowsOfflineFallback(scriptText, publicAudioPath);
    const buf = fsSync.existsSync(publicAudioPath) ? await fs.readFile(publicAudioPath) : Buffer.alloc(48000 * 10);
    const dur = Math.max(5, estimateWavDurationSec(buf));
    return {
      fileName,
      engineUsed: 'Windows Offline Local TTS',
      staticAudioPath: `generated-audio/${fileName}`,
      relativePath: `/public/generated-audio/${fileName}`,
      durationSec: dur,
      captions: buildHeuristicCaptions(scriptText, dur)
    };
  }

  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash-tts',
    contents: [{ role: 'user', parts: [{ text: scriptText }] }],
    config: {
      responseModalities: ['AUDIO'],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Aoede' } } }
    }
  });
  await incrementPersistentQuota('gemini-3.8-flash-tts', Math.round(scriptText.length / 4));

  const inlineData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
  if (!inlineData) throw new Error('خروجی صوتی از Gemini TTS دریافت نشد.');

  const audioBuffer = Buffer.from(inlineData.data, 'base64');
  await fs.writeFile(publicAudioPath, audioBuffer);
  const durationSec = Math.max(5, estimateWavDurationSec(audioBuffer));
  return {
    fileName,
    engineUsed: 'Gemini 3.8 Flash TTS',
    staticAudioPath: `generated-audio/${fileName}`,
    relativePath: `/public/generated-audio/${fileName}`,
    durationSec,
    captions: buildHeuristicCaptions(scriptText, durationSec)
  };
}
