import { GoogleGenAI } from '@google/genai';
import { ProxyAgent, setGlobalDispatcher, fetch as undiciFetch } from 'undici';
import net from 'net';
import dotenv from 'dotenv';
import { loadDb, getTodayKey, incrementPersistentQuota } from '../core/relational-db.js';
import { sysLog } from '../core/logger.js';
dotenv.config();

function isPortOpen(port) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    socket.setTimeout(250);
    socket.on('connect', () => { socket.destroy(); resolve(true); });
    socket.on('timeout', () => { socket.destroy(); resolve(false); });
    socket.on('error', () => resolve(false));
    socket.connect(port, '127.0.0.1');
  });
}

const candidatePorts = [10809, 7890, 2080, 1080, 8080, 10808];
for (const port of candidatePorts) {
  if (await isPortOpen(port)) {
    const proxyUrl = `http://127.0.0.1:${port}`;
    try {
      const dispatcher = new ProxyAgent(proxyUrl);
      const testRes = await undiciFetch('https://generativelanguage.googleapis.com', {
        dispatcher,
        signal: AbortSignal.timeout(3000)
      });
      if (testRes.status) {
        setGlobalDispatcher(dispatcher);
        globalThis.fetch = (url, opts = {}) => undiciFetch(url, { ...opts, dispatcher });
        sysLog('INFO', 'NetworkProxy', `تونل پراکسی فعال متصل شد: ${proxyUrl}`);
        break;
      }
    } catch {}
  }
}

export const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const MODEL_LIMITS = {
  'gemini-2.5-flash': { limit: 20, rpm: 5 },
  'gemini-3.5-flash-lite': { limit: 500, rpm: 15 },
  'gemini-3.1-flash-lite': { limit: 500, rpm: 15 },
  'gemini-3.8-flash': { limit: 20, rpm: 5 },
  'gemini-3.6-flash': { limit: 20, rpm: 5 },
  'gemini-4-hydrogen': { limit: 20, rpm: 5 },
  'gemini-3.8-flash-tts': { limit: 10, rpm: 3 },
  'gemini-3.5-transcribe': { limit: 25, rpm: 3 },
  'gemma-4-31b': { limit: 14400, rpm: 30 }
};

export const AGENT_ORG_CHART = [
  { id: 'ATOOZ_CORE', name: 'آتوز (ATOOZ)', role: 'دستیار ارشد فرماندهی و مکالمه زنده', dept: 'Command', avatar: '🧠', primaryModel: 'gemini-2.5-flash-native-audio-dialog', kpiName: 'دقت اجرای فرمان', kpiValue: '99.6%', bio: 'کنترلر هوشمند CMS با قابلیت ثبت ایده، باز کردن اتاق‌ها و مکالمه صوتی پیوسته.' },
  { id: 'PROD_DIR', name: 'آرش • مدیر تولید', role: 'مدیر صف تولید و رندر FIFO', dept: 'Production', avatar: '🎬', primaryModel: 'gemini-3.8-flash', kpiName: 'نرخ تحویل بدون خطا', kpiValue: '98.5%', bio: 'مدیریت صف تولید محتواهای تاییدشده و انتقال خروجی‌ها به گالری.' },
  { id: 'SCRIPT_DIR', name: 'پارسا • کارگردان فنی و سناریونویس', role: 'طراح مقالات سئو، ریلزها و کاروسل‌ها', dept: 'Production', avatar: '✍️', primaryModel: 'gemini-3.5-flash-lite', kpiName: 'نرخ ماندگاری مخاطب', kpiValue: '79%', bio: 'تبدیل ایده‌های تاییدشده به الگوهای اجرایی استاندارد.' },
  { id: 'ART_DIR', name: 'نگار • کارگردان هنری', role: 'طراح لایه‌های بصری و پالت برند', dept: 'Production', avatar: '🎨', primaryModel: 'gemini-3.6-flash', kpiName: 'انطباق با هویت بصری', kpiValue: '100%', bio: 'تنظیم چیدمان لایه‌ها، لوگوموشن و رعایت حریم امن اینستاگرام.' },
  { id: 'VOICE_ENG', name: 'رامتین • کارگردان صدا', role: 'مدیریت شخصیت‌های صوتی و کلون صدا', dept: 'Production', avatar: '🎙️', primaryModel: 'gemini-3.8-flash-tts', kpiName: 'دقت زیرنویس کلمه‌ای', kpiValue: '99.3%', bio: 'ضبط صدای شخصی، تولید نریشن فارسی و میکس افکت‌ها.' },
  { id: 'MKT_DIR', name: 'کیانوش • مدیر مارکتینگ و سئو', role: 'تحلیل ترندها و استراتژی قیف', dept: 'Marketing', avatar: '📈', primaryModel: 'gemini-2.5-flash', kpiName: 'نرخ ذخیره (Save Rate)', kpiValue: '9.4%', bio: 'جستجوی زنده وب و طراحی زاویه دیدهای تخصصی F&B.' },
  { id: 'PR_DIR', name: 'سارا • مدیر روابط عمومی', role: 'اتصال Webhook تلگرام و اینستاگرام', dept: 'PR', avatar: '💬', primaryModel: 'gemini-3.5-flash-lite', kpiName: 'سرعت پاسخگویی', kpiValue: '< 30s', bio: 'انتشار محتوا در کانال تلگرام و مدیریت تعاملات.' },
  { id: 'OPS_DIR', name: 'سهراب • مدیر منابع و سهمیه', role: 'پایش مصرف توکن و بهینه‌سازی API', dept: 'Resources', avatar: '🛡️', primaryModel: 'gemini-3.1-flash-lite', kpiName: 'صرفه‌جویی مصرف توکن', kpiValue: '85%', bio: 'جلوگیری از فراخوانی‌های تکراری و ثبت دائمی سهمیه مدل‌ها.' }
];

export const HIGH_CAPACITY_CHAIN = [
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-4-hydrogen',
  'gemini-2.5-flash'
];

export async function getPersistedQuotaSnapshot() {
  const db = await loadDb();
  const today = getTodayKey();
  const usage = db.dailyQuotaUsage?.[today] || {};
  const snapshot = {};
  for (const [model, meta] of Object.entries(MODEL_LIMITS)) {
    snapshot[model] = {
      used: usage[model]?.requests || 0,
      tokens: usage[model]?.tokens || 0,
      limit: meta.limit,
      rpm: meta.rpm
    };
  }
  return snapshot;
}

export async function runAgentTask(agentId, modelChain, payloadBuilder, handoffTarget = null) {
  const meta = AGENT_ORG_CHART.find((a) => a.id === agentId) || { name: agentId };
  const snapshot = await getPersistedQuotaSnapshot();
  let lastErr = null;

  for (const modelName of modelChain) {
    const q = snapshot[modelName];
    if (q && q.used >= q.limit) continue;

    try {
      const payload = payloadBuilder();
      const promptPreview = typeof payload.contents === 'string' ? payload.contents.slice(0, 320) + '...' : '[Payload]';
      sysLog('AGENT', meta.name, `ارسال به ${modelName}`, `PromptLen=${JSON.stringify(payload).length}`, {
        agent: meta.name,
        model: modelName,
        promptExcerpt: promptPreview
      });

      const res = await ai.models.generateContent({ model: modelName, ...payload });
      const tokens = Math.round((JSON.stringify(payload).length + (res.text?.length || 0)) / 4);
      await incrementPersistentQuota(modelName, tokens);

      sysLog('AGENT', meta.name, `پاسخ دریافت شد از ${modelName}`, `~${tokens} tokens`, {
        agent: meta.name,
        model: modelName,
        responseExcerpt: (res.text || '').slice(0, 420)
      });

      if (handoffTarget) {
        sysLog('HANDOFF', `${meta.name} ➔ ${handoffTarget}`, 'انتقال داده ساختاریافته');
      }
      return { text: res.text, modelUsed: modelName, tokens };
    } catch (err) {
      lastErr = err;
      const msg = err?.message || '';
      sysLog('WARN', meta.name, `سوییچ مدل از ${modelName}`, msg.slice(0, 90));
      if (msg.includes('503') || msg.includes('429') || msg.includes('UNAVAILABLE') || msg.includes('404')) continue;
      throw err;
    }
  }
  throw lastErr || new Error('تمام مدل‌های زنجیره با خطا مواجه شدند.');
}
