import fs from 'fs/promises';
import path from 'path';
import { ai, HIGH_CAPACITY_CHAIN, runAgentTask } from './model-router.js';
import { loadDb, createBlueprintRecord, incrementPersistentQuota, pushNotification } from '../core/relational-db.js';
import { sysLog } from '../core/logger.js';

async function loadKnowledgeAndSkills() {
  let context = '';
  for (const folder of ['knowledge-base', 'skills']) {
    try {
      const dir = path.resolve(folder);
      const entries = await fs.readdir(dir, { withFileTypes: true });
      for (const e of entries) {
        if (e.isFile() && e.name.endsWith('.md')) {
          const txt = await fs.readFile(path.join(dir, e.name), 'utf-8');
          context += `\n--- [${e.name}] ---\n${txt.slice(0, 1200)}`;
        }
      }
    } catch {}
  }
  return context;
}

export async function expandIdeaIntoConcepts({ rawIdea, sectionCode = 'Library', useWebSearch = true }) {
  const db = await loadDb();
  const kb = await loadKnowledgeAndSkills();

  let webContext = '';
  if (useWebSearch) {
    try {
      sysLog('AGENT', 'کیانوش • شکارچی ترند', `جستجوی زنده وب برای ایده: "${rawIdea}"`);
      const searchRes = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `تحقیق کن و داده‌های واقعی و آمار کلیدی مرتبط با این موضوع در صنعت غذا و نوشیدنی استخراج کن: "${rawIdea}"`,
        config: { tools: [{ googleSearch: {} }] }
      });
      await incrementPersistentQuota('gemini-2.5-flash', 700);
      webContext = searchRes.text || '';
    } catch (e) {
      sysLog('WARN', 'کیانوش • شکارچی ترند', 'سرچ وب با خطا مواجه شد', e.message);
    }
  }

  const prompt = `
  ${db.systemPrompts.IDEATION_STRATEGY}
  دانش‌پایه برند:
  ${kb}
  تحقیقات وب: ${webContext}

  موضوع خام کاربر: "${rawIdea}" | زیربرند هدف: ${sectionCode}

  این موضوع را تشریح کن و ۳ گزینه/زاویه دید (Concept) کاملاً متمایز و غیرکلیشه‌ای پیشنهاد بده.
  خروجی را دقیقاً در قالب JSON زیر برگردان:
  {
    "topicAnalysis": "تحلیل کوتاه استراتژیک از مسئله و نیاز مخاطب هدف",
    "concepts": [
      {
        "id": 1,
        "angleTitle": "عنوان زاویه دید اول",
        "summary": "شرح کامل اینکه این کانسپت چه مشکلی را حل می‌کند",
        "recommendedFunnel": "TOFU | MOFU | BOFU",
        "keyMetricExample": "+40%"
      }
    ]
  }`;

  const res = await runAgentTask('MKT_DIR', HIGH_CAPACITY_CHAIN, () => ({
    contents: prompt,
    config: { responseMimeType: 'application/json' }
  }), 'پارسا • سناریونویس');

  return JSON.parse(res.text);
}

export async function generateMultiDeliverableBatch({
  conceptTitle,
  conceptSummary,
  sectionCode = 'Library',
  funnelStage = 'MOFU',
  baseScheduleKey = 'M01-W01-D01',
  counts = { article: 1, reels: 1, youtube: 0, carousels: 1, posts: 0 },
  dialogueMode = false,
  selectedVoiceId = 'amir-clone'
}) {
  const db = await loadDb();
  const kb = await loadKnowledgeAndSkills();

  const deliverablesSpec = [];
  for (let i = 1; i <= (counts.article || 0); i++) deliverablesSpec.push({ type: 'article', label: `مقاله وب‌سایت ${i}`, fmt: 'MAG' });
  for (let i = 1; i <= (counts.reels || 0); i++) deliverablesSpec.push({ type: 'reel', label: `ریلز ۳۰ ثانیه‌ای ${i}`, fmt: 'ANM' });
  for (let i = 1; i <= (counts.youtube || 0); i++) deliverablesSpec.push({ type: 'youtube', label: `ویدئو بلند یوتیوب ${i}`, fmt: 'VID' });
  for (let i = 1; i <= (counts.carousels || 0); i++) deliverablesSpec.push({ type: 'carousel', label: `کاروسل آموزشی ${i}`, fmt: 'CAR' });
  for (let i = 1; i <= (counts.posts || 0); i++) deliverablesSpec.push({ type: 'post', label: `پست تکی اینفوگرافیک ${i}`, fmt: 'SNG' });

  if (deliverablesSpec.length === 0) {
    deliverablesSpec.push({ type: 'reel', label: 'ریلز آموزشی ۱', fmt: 'ANM' });
  }

  sysLog('INFO', 'ContentFactory', `ساخت ${deliverablesSpec.length} الگوی محتوایی برای: "${conceptTitle}"`);

  const prompt = `
  ${db.systemPrompts.UNIFIED_CONTENT_FACTORY}
  دانش‌پایه برند:
  ${kb}

  کانسپت تاییدشده: ${conceptTitle}
  شرح تفصیلی کانسپت: ${conceptSummary}
  زیربرند: ${sectionCode} | مرحله قیف: ${funnelStage}

  لیست دقیق اقلامی که باید در آرایه "deliverables" تولید کنی (${deliverablesSpec.length} آیتم):
  ${JSON.stringify(deliverablesSpec)}

  خروجی را دقیقاً در قالب JSON معتبر زیر برگردان:
  {
    "deliverables": [
      {
        "type": "article | reel | youtube | carousel | post",
        "title": "تیتر اختصاصی و جذاب",
        "subtitle": "زیرتیتر تحلیلی",
        "voiceoverScript": "متن نریشن فارسی آوایی بین ۶۵ تا ۷۵ کلمه بدون حروف انگلیسی",
        "articleHtml": "<h2>تیتر بخش</h2><p>متن کامل مقاله سئوشده</p>",
        "scenes": [
          {
            "id": 1,
            "eyebrow": "گام اول",
            "cardTitle": "عنوان کوتاه کارت",
            "metric": "42%+",
            "metricCaption": "توضیح کوتاه عدد",
            "items": ["نکته اجرایی ۱", "نکته اجرایی ۲", "نکته اجرایی ۳"]
          },
          {
            "id": 2,
            "eyebrow": "گام دوم • داده",
            "cardTitle": "مقایسه شاخص‌های کلیدی",
            "metric": "2.4x",
            "metricCaption": "شاخص بهره‌وری",
            "chartData": [
              { "label": "شاخص اول", "value": 42 },
              { "label": "شاخص دوم", "value": 68 },
              { "label": "شاخص سوم", "value": 25 }
            ],
            "items": ["نتیجه کلیدی اول", "نتیجه کلیدی دوم"]
          }
        ],
        "carouselSlides": [
          { "slideNumber": 1, "templateType": "cover", "badge": "${sectionCode}", "heading": "تیتر کاور", "body": "قلاب متنی", "highlightMetric": "AtoZ.FnB" },
          { "slideNumber": 2, "templateType": "comparison", "badge": "مقایسه", "heading": "تفاوت رویکردها", "body": "شرح مقایسه", "highlightMetric": "تحلیل داده" },
          { "slideNumber": 3, "templateType": "blueprint", "badge": "اجرا", "heading": "گام‌های عملی", "body": "راهنمای گام‌به‌گام", "highlightMetric": "چک‌لیست" },
          { "slideNumber": 4, "templateType": "cta", "badge": "گام بعدی", "heading": "دریافت ابزار از سایت", "body": "برای دانلود به atozfnb.info مراجعه کنید.", "highlightMetric": "ATOZFNB.INFO" }
        ],
        "socialPackage": {
          "instagramCaption": "کپشن کامل اینستاگرام",
          "telegramPost": "پست کانال تلگرام"
        }
      }
    ]
  }`;

  const res = await runAgentTask('SCRIPT_DIR', HIGH_CAPACITY_CHAIN, () => ({
    contents: prompt,
    config: { responseMimeType: 'application/json' }
  }), 'نگار • کارگردان هنری');

  const parsed = JSON.parse(res.text);
  const items = parsed.deliverables || [];
  const createdRecords = [];

  for (let idx = 0; idx < items.length; idx++) {
    const item = items[idx];
    const spec = deliverablesSpec[idx] || { type: item.type || 'reel', fmt: 'ANM' };
    const plt = spec.type === 'article' ? 'WEB' : spec.type === 'youtube' ? 'YT' : 'IG';
    const scheduleKey = `${baseScheduleKey}-${plt}-${spec.fmt}-0${idx + 1}`;
    item.sectionCode = sectionCode;
    item.selectedVoiceId = selectedVoiceId;

    const record = await createBlueprintRecord({
      title: item.title || `${conceptTitle} (${idx + 1})`,
      sectionCode,
      funnel_stage: funnelStage,
      schedule_key: scheduleKey,
      deliverableType: spec.type,
      status: 'blueprint_pending',
      plan: item,
      socialCopy: item.socialPackage
    });

    if (item.articleHtml) {
      await fs.writeFile(
        path.resolve('outputs/articles', `${record.content_id}-${spec.type}.html`),
        item.articleHtml,
        'utf-8'
      );
    }

    createdRecords.push({
      content_id: record.content_id,
      delivery_id: record.delivery_id,
      schedule_key: scheduleKey,
      type: spec.type,
      title: item.title || conceptTitle
    });
  }

  await pushNotification('success', `${createdRecords.length} الگوی تولید محتوا ساخته شد و در صف تایید شما قرار گرفت.`);
  return createdRecords;
}
