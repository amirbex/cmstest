import fs from 'fs/promises';
import fsSync from 'fs';
import path from 'path';

const DB_PATH = path.resolve('outputs/atoz-relational-db.json');
const DAYS_ORDER = ['D01', 'D02', 'D03', 'D04', 'D05', 'D06', 'D07'];

function build24PuzzleBlocks() {
  const blocks = [];
  const monthTitles = {
    1: 'فونداسیون، بوم کسب‌وکار و سیستم‌سازی پایه',
    2: 'مهندسی سود، عملیات پیشرفته و بهینه‌سازی',
    3: 'مقیاس‌پذیری (Scaling)، تجربه مشتری و رهبری بازار'
  };
  for (let m = 1; m <= 3; m++) {
    for (let w = 1; w <= 4; w++) {
      for (let p = 1; p <= 2; p++) {
        const code = `M0${m}-W0${w}-PART${p}`;
        blocks.push({
          period_code: code,
          batch_id: `ATZ-B-M0${m}-W0${w}-P${p}`,
          month: m,
          week: w,
          part: p,
          daysLabel: p === 1 ? 'شنبه تا سه‌شنبه (روزهای ۱ تا ۴)' : 'چهارشنبه تا جمعه (روزهای ۵ تا ۷)',
          phaseTitle: monthTitles[m],
          status: 'waiting_upload', // waiting_upload | blueprint_pending | approved_for_production | produced | published
          ideasCount: 0,
          deliveriesCount: 0,
          updatedAt: null
        });
      }
    }
  }
  return blocks;
}

const DEFAULT_SYSTEM_PROMPTS = {
  ATOOZ_CORE: `تو «آتوز (ATOOZ)» هستی؛ دستیار ارشد فرماندهی و کنترلر MCP سیستم جامع تولید محتوای AtoZ.FnB متعلق به امیر زمانی.
قوانین رفتاری:
1. کوتاه، دقیق، اجرایی و حرفه‌ای پاسخ بده.
2. اگر کاربر خواست ایده جدیدی ثبت یا بسط داده شود، action را "CREATE_IDEA" بگذار و موضوع را در ideaTopic بنویس و requiresConfirmation را true بگذار تا با تایید کاربر اجرا شود.
3. اگر کاربر خواست محتوایی را در استودیو ادیت باز کند، action را "MOVE_TO_EDIT" بگذار.
4. اگر کاربر فقط سوالی پرسید (مثل وضعیت تقویم یا آمار)، action را "NONE" و requiresConfirmation را false بگذار.`,

  IDEATION_STRATEGY: `تو سردبیر ارشد (Editor-in-Chief) و مدیر مارکتینگ AtoZ.FnB هستی.
مأموریت: موضوع خام را تحلیل کن و ۳ کانسپت کاملاً متمایز، غیرکلیشه‌ای و داده‌محور برای صنعت F&B ایران پیشنهاد بده.
قانون ضدکلیشه: هرگز از مثال‌های تکراری نامرتبط (مثل قانون 30/30/30/10) استفاده نکن مگر موضوع واقعاً درباره بودجه‌بندی کل رستوران باشد. هر کانسپت باید یک شاخص عددی کوتاه (حداکثر ۵ کاراکتر مثل "+40%" یا "2.5x") داشته باشد.`,

  UNIFIED_CONTENT_FACTORY: `تو هسته کارخانه تولید محتوای AtoZ.FnB هستی. بر اساس کانسپت انتخاب‌شده، لیست دارایی‌های موجود برند و تعداد دقیق خروجی‌های درخواستی کاربر، یک بسته JSON یکپارچه و ضدگلوله تولید کن.
قوانین اجباری:
1. تعداد دقیق اقلام درخواستی کاربر (مقاله، ریلز، کاروسل، پست تکی، یوتیوب) را تولید کن.
2. در فیلد "metric" کارت‌ها فقط عدد یا شاخص کوتاه بنویس (مثل "45%+" یا "3 گام") و توضیح آن را در "metricCaption" (حداکثر ۶ کلمه) قرار بده.
3. در "voiceoverScript" هیچ کلمه انگلیسی یا خط تیره بین اعداد ننویس؛ معادل آوایی فارسی بنویس تا موتور TTS بدون خطا بخواند.`,

  SEO_AND_HTML_EDITOR: `تو ویراستار فنی سئو و توسعه‌دهنده وب AtoZ.FnB هستی. متن مقاله را با تگ‌های معنایی HTML5 و کلاس‌های Tailwind CSS (dir="rtl") ساختاردهی کن.`
};

const DEFAULT_VOICE_CAST = [
  { id: 'amir-clone', name: 'امیر زمانی (صدای شخصی کلون‌شده)', role: 'بنیان‌گذار و استراتژیست ارشد', engine: 'local-f5-clone', sampleFile: 'my-voice.wav', promptStyle: 'مقتدر، دلسوز، تحلیلی و صریح' },
  { id: 'farid-neural', name: 'فرید (راوی مستند فارسی)', role: 'گوینده آموزشی و تحلیلی', engine: 'local-kokoro', sampleFile: '', promptStyle: 'شمرده، شفاف و حرفه‌ای' },
  { id: 'aoede-gemini', name: 'آئود (میزبان گفتگو)', role: 'پرسشگر و مجری پادکست دو نفره', engine: 'gemini', sampleFile: '', promptStyle: 'پرانرژی، کنجکاو و محاوره‌ای' }
];

const initialDb = {
  counters: { content: 1, asset: 1, delivery: 1 },
  dailyQuotaUsage: {},
  puzzleBlocks: build24PuzzleBlocks(),
  systemPrompts: DEFAULT_SYSTEM_PROMPTS,
  voiceCast: DEFAULT_VOICE_CAST,
  notifications: [
    { id: 'N-1', time: new Date().toTimeString().slice(0, 5), type: 'info', text: 'AtoZ.FnB Content CMS v5.0 با ویرایشگر لایه‌ای و تایم‌لاین تدوین آماده به کار است.' }
  ],
  socialWebhooks: {
    telegramBotToken: '',
    telegramChannelId: '',
    instagramGraphToken: ''
  },
  contents: [],
  assets: [],
  deliveries: []
};

export async function loadDb() {
  if (!fsSync.existsSync(DB_PATH)) {
    await fs.writeFile(DB_PATH, JSON.stringify(initialDb, null, 2), 'utf-8');
    return structuredClone(initialDb);
  }
  const parsed = JSON.parse(await fs.readFile(DB_PATH, 'utf-8'));
  return {
    ...structuredClone(initialDb),
    ...parsed,
    puzzleBlocks: parsed.puzzleBlocks?.length === 24 ? parsed.puzzleBlocks : build24PuzzleBlocks(),
    systemPrompts: { ...DEFAULT_SYSTEM_PROMPTS, ...(parsed.systemPrompts || {}) },
    voiceCast: parsed.voiceCast?.length ? parsed.voiceCast : DEFAULT_VOICE_CAST
  };
}

export async function saveDb(db) {
  await fs.writeFile(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
}

export async function pushNotification(type, text) {
  const db = await loadDb();
  db.notifications.unshift({
    id: `N-${Date.now()}`,
    time: new Date().toTimeString().slice(0, 5),
    type,
    text
  });
  if (db.notifications.length > 30) db.notifications.length = 30;
  await saveDb(db);
}

export function pad6(num) {
  return String(num).padStart(6, '0');
}

export function getTodayKey() {
  return new Date().toISOString().slice(0, 10);
}

export async function incrementPersistentQuota(modelName, tokensUsed = 0) {
  const db = await loadDb();
  const today = getTodayKey();
  if (!db.dailyQuotaUsage[today]) db.dailyQuotaUsage[today] = {};
  if (!db.dailyQuotaUsage[today][modelName]) {
    db.dailyQuotaUsage[today][modelName] = { requests: 0, tokens: 0 };
  }
  db.dailyQuotaUsage[today][modelName].requests += 1;
  db.dailyQuotaUsage[today][modelName].tokens += tokensUsed;
  await saveDb(db);
  return db.dailyQuotaUsage[today];
}

// Create Blueprint Record (Does NOT jump straight to Jalali Calendar until approved & produced!)
export async function createBlueprintRecord({
  batch_id = 'ATZ-B-CUSTOM',
  explicitContentId = null,
  explicitDeliveryId = null,
  title,
  sectionCode = 'Library',
  funnel_stage = 'MOFU',
  schedule_key = 'M01-W01-D01-IG-ANM-01',
  deliverableType = 'reel',
  plan,
  socialCopy,
  status = 'blueprint_pending' // blueprint_pending | approved_for_production | produced | published
}) {
  const db = await loadDb();
  const cNum = db.counters.content++;
  const aNum = db.counters.asset++;
  const dNum = db.counters.delivery++;

  const content_id = explicitContentId || `ATZ-C-${pad6(cNum)}`;
  const asset_id = `ATZ-A-${pad6(aNum)}-FINAL-V1`;
  const delivery_id = explicitDeliveryId || `ATZ-D-${pad6(dNum)}`;

  const existingContent = db.contents.find((c) => c.content_id === content_id);
  if (!existingContent) {
    db.contents.unshift({
      content_id,
      batch_id,
      title,
      sectionCode,
      deliverableType,
      status,
      plan,
      socialCopy,
      folder: 'blueprints',
      createdAt: new Date().toISOString()
    });
  }

  const existingAsset = db.assets.find((a) => a.content_id === content_id);
  if (!existingAsset) {
    db.assets.unshift({
      asset_id,
      content_id,
      title,
      sectionCode,
      type: deliverableType,
      status,
      folder: 'outputs',
      files: [],
      createdAt: new Date().toISOString()
    });
  }

  const existingDel = db.deliveries.find((d) => d.delivery_id === delivery_id);
  if (!existingDel) {
    db.deliveries.unshift({
      delivery_id,
      batch_id,
      content_id,
      asset_id,
      title,
      schedule_key,
      funnel_stage,
      status, // Only 'produced' or 'published' items appear in Jalali Publishing Calendar!
      platform_post_id: null,
      rolloverCount: 0,
      raw_metrics: { reach: 0, views: 0, saves: 0, shares: 0, clicks: 0, avg_watch_time_sec: 0, video_duration_sec: 30 },
      calculated_kpis: { save_rate: 0, share_rate: 0, ctr: 0, avg_watch_ratio: 0 }
    });
  }

  await saveDb(db);
  return { content_id, asset_id, delivery_id };
}

// Zero-Token JSON Blueprint Ingestion (Parses user's pre-crafted JSON directly without burning AI quota!)
export async function ingestWeeklyPuzzleJson(puzzleJson) {
  const db = await loadDb();
  const meta = puzzleJson.schema_metadata || {};
  const periodCode = meta.period_code || 'M01-W01-PART1';
  const batchId = meta.batch_id || `ATZ-B-${periodCode.replace('PART', 'P')}`;

  const ideas = puzzleJson.content_ideas || [];
  const deliveries = puzzleJson.deliveries || [];

  const mapPillarToSection = (pillarStr = '') => {
    if (pillarStr.includes('P1')) return 'Library';
    if (pillarStr.includes('P2')) return 'Solutions';
    if (pillarStr.includes('P3')) return 'AI';
    if (pillarStr.includes('P4')) return 'Calculators';
    if (pillarStr.includes('P5')) return 'Magazine';
    if (pillarStr.includes('P6')) return 'Academy';
    return 'Library';
  };

  for (const idea of ideas) {
    const sec = mapPillarToSection(idea.pillar);
    // Find matching deliveries for this content_id in the uploaded JSON to extract pre-written slides/timeline/caption!
    const linkedDeliveries = deliveries.filter((d) => d.content_id === idea.content_id);
    const primaryDel = linkedDeliveries[0] || {};
    const exact = primaryDel.exact_content || {};

    const extractedScenes = Array.isArray(exact.timeline) && exact.timeline.length > 0
      ? exact.timeline.map((t, i) => ({
          id: i + 1,
          eyebrow: t.time || `بخش ${i + 1}`,
          cardTitle: t.on_screen_text || idea.title,
          metric: `${i + 1}/${exact.timeline.length}`,
          metricCaption: idea.thread || '',
          items: [t.narration_script || t.on_screen_text || idea.title]
        }))
      : [
          {
            id: 1,
            eyebrow: idea.pillar || sec,
            cardTitle: idea.title,
            metric: 'AtoZ',
            metricCaption: idea.thread || '',
            items: [exact.ready_caption?.slice(0, 90) || idea.title]
          }
        ];

    const extractedSlides = Array.isArray(exact.slides) && exact.slides.length > 0
      ? exact.slides.map((s) => ({
          slideNumber: s.slide_number || 1,
          templateType: s.slide_number === 1 ? 'cover' : 'blueprint',
          badge: sec,
          heading: s.title || idea.title,
          body: s.body_text || '',
          highlightMetric: 'AtoZ.FnB'
        }))
      : [
          { slideNumber: 1, templateType: 'cover', badge: sec, heading: idea.title, body: idea.thread || '', highlightMetric: 'AtoZ.FnB' }
        ];

    const voiceScript = Array.isArray(exact.timeline)
      ? exact.timeline.map((t) => t.narration_script || t.on_screen_text).filter(Boolean).join(' ')
      : (exact.ready_caption || idea.title);

    await createBlueprintRecord({
      batch_id: batchId,
      explicitContentId: idea.content_id,
      title: idea.title,
      sectionCode: sec,
      deliverableType: primaryDel.format_type || 'multi-channel',
      status: 'blueprint_pending',
      plan: {
        title: idea.title,
        subtitle: idea.thread || idea.pillar,
        sectionCode: sec,
        voiceoverScript: voiceScript,
        scenes: extractedScenes,
        carouselSlides: extractedSlides,
        articleHtml: exact.article_outline || exact.page_copy || ''
      },
      socialCopy: {
        instagramCaption: exact.ready_caption || '',
        telegramPost: exact.ready_post_text || ''
      }
    });
  }

  for (const del of deliveries) {
    const sec = mapPillarToSection(del.content_pillar);
    await createBlueprintRecord({
      batch_id: batchId,
      explicitContentId: del.content_id,
      explicitDeliveryId: del.delivery_id,
      title: del.strategic_positioning?.topic || del.format_type,
      sectionCode: sec,
      funnel_stage: del.funnel_stage || 'MOFU',
      schedule_key: del.schedule_key,
      deliverableType: del.format_type || 'reel',
      status: 'blueprint_pending',
      plan: { title: del.strategic_positioning?.topic || del.format_type, sectionCode: sec, scenes: [], carouselSlides: [] },
      socialCopy: del.exact_content || {}
    });
  }

  const freshDb = await loadDb();
  const block = freshDb.puzzleBlocks.find((b) => b.period_code === periodCode || b.batch_id === batchId);
  if (block) {
    block.status = 'blueprint_pending';
    block.ideasCount = ideas.length;
    block.deliveriesCount = deliveries.length;
    block.updatedAt = new Date().toISOString();
  }
  await saveDb(freshDb);
  await pushNotification('info', `بلوک ${periodCode} بدون مصرف توکن به ${ideas.length} الگو تبدیل شد و منتظر تایید شماست.`);
  return { periodCode, batchId, ideasCount: ideas.length, deliveriesCount: deliveries.length };
}

export async function approveBlueprintsForProduction({ contentIds = null, periodCode = null }) {
  const db = await loadDb();
  let targetBatchId = null;
  if (periodCode) {
    const blk = db.puzzleBlocks.find((b) => b.period_code === periodCode);
    if (blk) {
      targetBatchId = blk.batch_id;
      blk.status = 'approved_for_production';
    }
  }

  let count = 0;
  for (const c of db.contents) {
    if ((targetBatchId && c.batch_id === targetBatchId) || (Array.isArray(contentIds) && contentIds.includes(c.content_id))) {
      c.status = 'approved_for_production';
      c.folder = 'production_queue';
      count++;
    }
  }
  for (const d of db.deliveries) {
    if ((targetBatchId && d.batch_id === targetBatchId) || (Array.isArray(contentIds) && contentIds.includes(d.content_id))) {
      d.status = 'approved_for_production';
    }
  }
  await saveDb(db);
  await pushNotification('success', `${count} الگو تایید شد و به صف تولید (Production Queue) منتقل گردید.`);
  return { approvedCount: count };
}

export async function recordClosedLoopMetrics(deliveryId, metrics) {
  const db = await loadDb();
  const item = db.deliveries.find((d) => d.delivery_id === deliveryId);
  if (!item) throw new Error('Delivery not found');
  const reach = Math.max(1, Number(metrics.reach) || 1);
  const saves = Number(metrics.saves) || 0;
  const shares = Number(metrics.shares) || 0;
  const clicks = Number(metrics.clicks) || 0;
  const watchSec = Number(metrics.avg_watch_time_sec) || 0;
  const durSec = Math.max(1, Number(metrics.video_duration_sec) || 30);

  item.raw_metrics = { reach, views: Number(metrics.views) || reach, saves, shares, clicks, avg_watch_time_sec: watchSec, video_duration_sec: durSec };
  item.calculated_kpis = {
    save_rate: Number(((saves / reach) * 100).toFixed(2)),
    share_rate: Number(((shares / reach) * 100).toFixed(2)),
    ctr: Number(((clicks / reach) * 100).toFixed(2)),
    avg_watch_ratio: Number(((watchSec / durSec) * 100).toFixed(1))
  };
  await saveDb(db);
  return item;
}

export async function rolloverDelivery(deliveryId) {
  const db = await loadDb();
  const item = db.deliveries.find((d) => d.delivery_id === deliveryId);
  if (!item) throw new Error('Delivery not found');

  const parts = item.schedule_key.split('-');
  if (parts.length >= 6) {
    const dayIdx = DAYS_ORDER.indexOf(parts[2]);
    if (dayIdx >= 0 && dayIdx < DAYS_ORDER.length - 1) {
      parts[2] = DAYS_ORDER[dayIdx + 1];
    } else {
      parts[2] = 'D01';
      const wNum = parseInt(parts[1].replace('W', ''), 10) || 1;
      parts[1] = `W0${Math.min(4, wNum + 1)}`;
    }
    item.schedule_key = parts.join('-');
  }
  item.rolloverCount = (item.rolloverCount || 0) + 1;
  await saveDb(db);
  return item;
}

export async function markDeliveryPublished(deliveryId, platformPostId) {
  const db = await loadDb();
  const item = db.deliveries.find((d) => d.delivery_id === deliveryId);
  if (!item) throw new Error('Delivery not found');
  item.status = 'published';
  item.platform_post_id = platformPostId || `POST-${Date.now()}`;
  item.publishedAt = new Date().toISOString();
  await saveDb(db);
  return item;
}

export async function moveContentToFolder(contentId, targetFolder) {
  const db = await loadDb();
  const content = db.contents.find((c) => c.content_id === contentId);
  const asset = db.assets.find((a) => a.content_id === contentId);
  if (content) content.folder = targetFolder;
  if (asset) asset.folder = targetFolder;
  await saveDb(db);
  return { contentId, targetFolder };
}
