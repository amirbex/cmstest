import fs from 'fs';
import path from 'path';

const LOG_FILE = path.resolve('outputs/system-live-logs.json');
const MAX_LOGS = 400;
let memoryLogs = [];

try {
  if (fs.existsSync(LOG_FILE)) {
    memoryLogs = JSON.parse(fs.readFileSync(LOG_FILE, 'utf-8'));
  }
} catch {
  memoryLogs = [];
}

export function sysLog(level, source, message, details = null, tracePayload = null) {
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
    timeShort: new Date().toTimeString().slice(0, 8),
    level: level.toUpperCase(),
    source,
    message,
    details: details ? (typeof details === 'string' ? details : JSON.stringify(details)) : null,
    tracePayload: tracePayload ? (typeof tracePayload === 'string' ? tracePayload : JSON.stringify(tracePayload, null, 2)) : null
  };

  memoryLogs.unshift(entry);
  if (memoryLogs.length > MAX_LOGS) memoryLogs.length = MAX_LOGS;
  console.log(`[${entry.timeShort}] [${entry.level}] (${entry.source}) ${entry.message}${entry.details ? ` -> ${entry.details}` : ''}`);
  fs.promises.writeFile(LOG_FILE, JSON.stringify(memoryLogs, null, 2), 'utf-8').catch(() => {});
  return entry;
}

export function getLogs(limit = 150, levelFilter = 'ALL') {
  const filtered = levelFilter === 'ALL' ? memoryLogs : memoryLogs.filter((l) => l.level === levelFilter);
  return filtered.slice(0, limit);
}

export function clearLogs() {
  memoryLogs = [];
  fs.promises.writeFile(LOG_FILE, '[]', 'utf-8').catch(() => {});
}
