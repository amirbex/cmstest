import express from 'express';
import cors from 'cors';
import multer from 'multer';
import os from 'os';
import path from 'path';
import fs from 'fs/promises';
import fsSync from 'fs';
import { exec } from 'child_process';
import { promisify } from 'util';
import archiver from 'archiver';
import { sysLog, getLogs, clearLogs } from '../core/logger.js';
import { expandIdeaIntoConcepts, generateMultiDeliverableBatch } from '../ai-agents/orchestrator.js';
import { synthesizeHybridVoice } from '../ai-agents/voice-engine.js';
import { chatWithAtooz } from '../ai-agents/atooz-copilot.js';
import { AGENT_ORG_CHART, getPersistedQuotaSnapshot } from '../ai-agents/model-router.js';
import {
  loadDb,
  saveDb,
  rolloverDelivery,
  markDeliveryPublished,
  recordClosedLoopMetrics,
  ingestWeeklyPuzzleJson,
  approveBlueprintsForProduction,
  pushNotification
} from '../core/relational-db.js';

const execAsync = promisify(exec);
const app = express();
app.use(cors());
app.use(express.json({ limit: '40mb' }));

app.use('/public', (req, res, next) => { res.setHeader('Content-Disposition', 'inline'); next(); }, express.static('public'));
app.use('/outputs', (req, res, next) => { res.setHeader('Content-Disposition', 'inline'); next(); }, express.static('outputs'));
app.use('/', express.static('src/dashboard'));

function getSystemBrowserFlag() {
  const candidates = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
  ];
  const found = candidates.find((p) => fsSync.existsSync(p));
  return found ? `--browser-executable="${found}"` : '';
}

function getSystemTelemetry() {
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMemPct = Math.round(((totalMem - freeMem) / totalMem) * 100);
  const cpus = os.cpus();
  const loadAvg = os.loadavg()[0] || 0.35;
  const cpuPct = Math.min(98, Math.max(8, Math.round((loadAvg / Math.max(1, cpus.length)) * 100) + 12));
  return {
    cpuUsagePct: cpuPct,
    ramTotalGb: (totalMem / 1073741824).toFixed(1),
    ramUsedGb: ((totalMem - freeMem) / 1073741824).toFixed(1),
    ramUsagePct: usedMemPct
  };
}

const renderQueue = [];
let isRendering = false;

async function processNextRenderJob() {
  if (isRendering || renderQueue.length === 0) return;
  isRendering = true;
  const job = renderQueue.shift();
  const { plan, format, contentId, resolve, reject } = job;

  try {
    const propsPath = path.resolve('outputs/render-props.json');
    await fs.writeFile(propsPath, JSON.stringify(plan, null, 2));
    const browserFlag = getSystemBrowserFlag();
    const prefix = contentId || `ATZ-${Date.now()}`;

    sysLog('RENDER', 'FIFO-QueueWorker', `شروع رندر (${format}) برای ${prefix}`);

    let outputPaths = [];
    if (format === 'cover') {
      const outFile = `outputs/covers/${prefix}-CVR-V1.png`;
      await execAsync(`npx remotion still src/render-engine/index.ts PostCover ${outFile} --props="${propsPath}" ${browserFlag}`);
      outputPaths.push(`/${outFile}`);
    } else if (format === 'carousel') {
      const slides = plan.carouselSlides || [];
      for (let i = 0; i < slides.length; i++) {
        const sPath = path.resolve(`outputs/slide-props-${i}.json`);
        await fs.writeFile(sPath, JSON.stringify({ ...slides[i], sectionCode: plan.sectionCode || 'Library', totalSlides: slides.length }, null, 2));
        const outFile = `outputs/carousels/${prefix}-S0${i + 1}-V1.png`;
        await execAsync(`npx remotion still src/render-engine/index.ts CarouselSlide ${outFile} --props="${sPath}" ${browserFlag}`);
        outputPaths.push(`/${outFile}`);
      }
    } else {
      const outFile = `outputs/reels/${prefix}-FINAL-V1.mp4`;
      await execAsync(`npx remotion render src/render-engine/index.ts ReelVertical ${outFile} --props="${propsPath}" ${browserFlag}`);
      outputPaths.push(`/${outFile}`);
    }

    if (contentId) {
      const db = await loadDb();
      const content = db.contents.find((c) => c.content_id === contentId);
      const asset = db.assets.find((a) => a.content_id === contentId);
      const delivery = db.deliveries.find((d) => d.content_id === contentId);
      if (content) content.status = 'produced';
      if (asset) {
        asset.status = 'produced';
        asset.files = [...new Set([...(asset.files || []), ...outputPaths])];
      }
      if (delivery) delivery.status = 'produced';
      await saveDb(db);
    }

    await pushNotification('success', `خروجی ${format} برای ${prefix} تولید شد و در گالری خروجی‌ها و تقویم جلالی قرار گرفت.`);
    resolve({ success: true, outputs: outputPaths });
  } catch (err) {
    sysLog('ERROR', 'FIFO-QueueWorker', 'خطا در صف رندر', err.message);
    reject(err);
  } finally {
    isRendering = false;
    processNextRenderJob();
  }
}

function enqueueRenderJob(payload) {
  return new Promise((resolve, reject) => {
    renderQueue.push({ ...payload, resolve, reject });
    processNextRenderJob();
  });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const folder = req.body.folder || 'backgrounds';
    const dest = path.join('public', folder);
    fsSync.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, '_')}`)
});
const upload = multer({ storage });

async function scanFolderTree() {
  const folderDefs = [
    { id: 'parent-logos', title: 'لوگوهای اصلی مادر (Parent Brand)', dir: 'public/assets/parent' },
    { id: 'sub-AI', title: 'زیربرند هوش مصنوعی (AtoZ AI)', dir: 'public/assets/subbrands/AI' },
    { id: 'sub-Library', title: 'زیربرند کتابخانه (AtoZ Library)', dir: 'public/assets/subbrands/Library' },
    { id: 'sub-Magazine', title: 'زیربرند مجله (AtoZ Magazine)', dir: 'public/assets/subbrands/Magazine' },
    { id: 'sub-Calculators', title: 'زیربرند ماشین‌حساب (Calculators)', dir: 'public/assets/subbrands/Calculators' },
    { id: 'sub-Solutions', title: 'زیربرند راهکارها (Solutions)', dir: 'public/assets/subbrands/Solutions' },
    { id: 'sub-Academy', title: 'زیربرند آکادمی (Academy)', dir: 'public/assets/subbrands/Academy' },
    { id: 'social-icons', title: 'آیکون‌های شبکه‌های اجتماعی', dir: 'public/assets/icons' },
    { id: 'logo-motions', title: 'لوگوموشن‌ها', dir: 'public/logo-motions' },
    { id: 'backgrounds', title: 'پس‌زمینه‌ها', dir: 'public/backgrounds' },
    { id: 'voice-samples', title: 'نمونه‌های صدای شخصی', dir: 'public/voice-samples' },
    { id: 'sfx', title: 'افکت‌های صوتی و موزیک', dir: 'public/sfx' }
  ];
  const tree = [];
  for (const def of folderDefs) {
    const abs = path.resolve(def.dir);
    const filesList = [];
    if (fsSync.existsSync(abs)) {
      const walk = (d, webPrefix) => {
        for (const entry of fsSync.readdirSync(d, { withFileTypes: true })) {
          if (entry.name.startsWith('.')) continue;
          const full = path.join(d, entry.name);
          const url = `${webPrefix}/${entry.name}`;
          if (entry.isDirectory()) walk(full, url);
          else filesList.push({ name: entry.name, url });
        }
      };
      walk(abs, `/${def.dir}`);
    }
    tree.push({ id: def.id, title: def.title, dir: def.dir, count: filesList.length, files: filesList });
  }
  return tree;
}

app.get('/api/logs', (req, res) => res.json({ success: true, logs: getLogs(150, req.query.level || 'ALL') }));
app.delete('/api/logs', (req, res) => { clearLogs(); res.json({ success: true }); });

app.get('/api/state', async (req, res) => {
  const db = await loadDb();
  const folderTree = await scanFolderTree();
  const quotas = await getPersistedQuotaSnapshot();
  let pythonOnline = false;
  try {
    const py = await fetch(`${process.env.PYTHON_ENGINE_URL || 'http://127.0.0.1:5005'}/health`, { signal: AbortSignal.timeout(500) });
    pythonOnline = py.ok;
  } catch {}
  res.json({
    success: true,
    db,
    orgChart: AGENT_ORG_CHART,
    quotas,
    queueLength: renderQueue.length + (isRendering ? 1 : 0),
    system: { ...getSystemTelemetry(), pythonOnline },
    folderTree,
    logs: getLogs(120, 'ALL')
  });
});

app.post('/api/puzzle/upload-block', async (req, res) => {
  try {
    const summary = await ingestWeeklyPuzzleJson(req.body.puzzleJson);
    res.json({ success: true, summary });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/blueprints/approve', async (req, res) => {
  try {
    const result = await approveBlueprintsForProduction(req.body);
    res.json({ success: true, result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/voice/save-recording', async (req, res) => {
  try {
    const { base64Audio, fileName } = req.body;
    const cleanName = (fileName || 'my-voice.wav').replace(/[^a-zA-Z0-9._-]/g, '_');
    const outPath = path.resolve('public/voice-samples', cleanName);
    const rawBase64 = base64Audio.replace(/^data:audio\/\w+;base64,/, '');
    await fs.writeFile(outPath, Buffer.from(rawBase64, 'base64'));
    await pushNotification('success', `صدای شخصی «${cleanName}» ذخیره شد.`);
    res.json({ success: true, fileName: cleanName, url: `/public/voice-samples/${cleanName}` });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/voice/add-character', async (req, res) => {
  const db = await loadDb();
  db.voiceCast.unshift({
    id: `char-${Date.now()}`,
    name: req.body.name,
    role: req.body.role || 'گوینده',
    engine: req.body.engine || 'local-f5-clone',
    sampleFile: req.body.sampleFile || 'my-voice.wav',
    promptStyle: req.body.promptStyle || 'حرفه‌ای'
  });
  await saveDb(db);
  res.json({ success: true });
});

app.post('/api/settings/prompts', async (req, res) => {
  const db = await loadDb();
  db.systemPrompts = { ...db.systemPrompts, ...req.body.systemPrompts };
  await saveDb(db);
  res.json({ success: true });
});

app.post('/api/settings/webhooks', async (req, res) => {
  const db = await loadDb();
  db.socialWebhooks = { ...db.socialWebhooks, ...req.body };
  await saveDb(db);
  res.json({ success: true });
});

app.post('/api/agency/expand-concepts', async (req, res) => {
  try {
    const data = await expandIdeaIntoConcepts(req.body);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/agency/generate-batch', async (req, res) => {
  try {
    const records = await generateMultiDeliverableBatch(req.body);
    res.json({ success: true, records });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/atooz/chat', async (req, res) => {
  try {
    const result = await chatWithAtooz(req.body.message, req.body.confirmedAction, req.body.speakReply);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/assets/upload', upload.single('file'), async (req, res) => {
  const folder = req.body.folder || 'backgrounds';
  const relPath = `${folder}/${req.file.filename}`;
  res.json({ success: true, path: relPath, url: `/public/${relPath}` });
});

app.post('/api/agency/voice', async (req, res) => {
  try {
    const result = await synthesizeHybridVoice(req.body);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/calendar/publish', async (req, res) => {
  try {
    const updated = await markDeliveryPublished(req.body.deliveryId, req.body.platformPostId);
    res.json({ success: true, delivery: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/calendar/rollover', async (req, res) => {
  try {
    const updated = await rolloverDelivery(req.body.deliveryId);
    res.json({ success: true, delivery: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/bi/record-metrics', async (req, res) => {
  try {
    const updated = await recordClosedLoopMetrics(req.body.deliveryId, req.body);
    res.json({ success: true, delivery: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/render', async (req, res) => {
  try {
    const result = await enqueueRenderJob(req.body);
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/package/zip/:contentId', async (req, res) => {
  const { contentId } = req.params;
  res.attachment(`${contentId}-full-package.zip`);
  const archive = archiver('zip', { zlib: { level: 9 } });
  archive.pipe(res);
  for (const sub of ['reels', 'carousels', 'covers', 'articles']) {
    const dir = path.resolve('outputs', sub);
    if (fsSync.existsSync(dir)) {
      for (const f of fsSync.readdirSync(dir)) {
        if (f.startsWith(contentId)) archive.file(path.join(dir, f), { name: `${sub}/${f}` });
      }
    }
  }
  await archive.finalize();
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => sysLog('INFO', 'ServerBoot', `AtoZ.FnB Content CMS v5.0 آماده به کار است -> http://localhost:${PORT}`));
