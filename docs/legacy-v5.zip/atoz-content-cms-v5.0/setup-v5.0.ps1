Write-Host "Initializing AtoZ.FnB Content CMS v5.0..." -ForegroundColor Cyan
npm install --no-audit --no-fund

if (Get-Command git -ErrorAction SilentlyContinue) {
    if (-not (Test-Path "external-tools/open-design")) {
        git clone --depth 1 https://github.com/nexu-io/open-design.git external-tools/open-design
    }
    if (-not (Test-Path "external-tools/remotion")) {
        git clone --depth 1 --filter=blob:none --sparse https://github.com/remotion-dev/remotion.git external-tools/remotion
        Push-Location external-tools/remotion
        git sparse-checkout set packages/skills
        Pop-Location
    }
    if (-not (Test-Path "external-tools/hyperframes")) {
        git clone --depth 1 https://github.com/heygen-com/hyperframes.git external-tools/hyperframes
    }
    if (-not (Test-Path "external-tools/anatomy")) {
        git clone --depth 1 https://github.com/wheresryan22/anatomy.git external-tools/anatomy
    }
}

Write-Host "Installing Python Engine dependencies..." -ForegroundColor Yellow
pip install -r python-engine/requirements.txt
Write-Host "Setup Complete! Run 'npm run dev' and 'npm run python:engine'." -ForegroundColor Green
