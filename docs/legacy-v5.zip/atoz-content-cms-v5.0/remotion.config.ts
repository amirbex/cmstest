import { Config } from '@remotion/cli/config';
import fs from 'fs';

const browserCandidates = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
];

const foundBrowser = browserCandidates.find((p) => fs.existsSync(p));
if (foundBrowser) {
  Config.setBrowserExecutable(foundBrowser);
}
