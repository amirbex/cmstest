import json
from pathlib import Path
db_file = Path(__file__).resolve().parent.parent / 'outputs' / 'atoz-relational-db.json'
print("Schema OK" if db_file.exists() else "Ready")
