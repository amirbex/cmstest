import os
import wave
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="AtoZ.FnB Local AI, Charts, TTS & Keyframe Engine v5.0")

class TTSRequest(BaseModel):
    text: str
    mode: str = "local-kokoro"
    sample_path: Optional[str] = None
    output_path: str

class TranscribeRequest(BaseModel):
    audio_path: str

def get_audio_duration(filepath: str) -> float:
    try:
        with wave.open(filepath, 'rb') as wf:
            return round(wf.getnframes() / float(wf.getframerate()), 2)
    except Exception:
        return 12.0

@app.get("/health")
def health():
    return {"status": "online", "engine": "AtoZ Python Media & TTS Engine v5.0"}

@app.post("/transcribe")
def transcribe_audio(req: TranscribeRequest):
    if not os.path.exists(req.audio_path):
        raise HTTPException(status_code=404, detail="Audio file not found")
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel("base", device="cpu", compute_type="int8")
        segments, _ = model.transcribe(req.audio_path, language="fa", word_timestamps=True)
        captions = []
        for seg in segments:
            words = [{"text": w.word.strip(), "start": round(w.start, 2), "end": round(w.end, 2)} for w in (seg.words or [])]
            if words:
                captions.append({"start": round(seg.start, 2), "end": round(seg.end, 2), "words": words})
        return {"success": True, "captions": captions}
    except Exception as e:
        return {"success": False, "error": str(e), "captions": []}

@app.post("/tts")
async def generate_local_tts(req: TTSRequest):
    os.makedirs(os.path.dirname(req.output_path), exist_ok=True)
    if req.mode == "local-f5-clone" and req.sample_path and os.path.exists(req.sample_path):
        try:
            from f5_tts.api import F5TTS
            f5 = F5TTS()
            f5.infer(ref_file=req.sample_path, ref_text="", gen_text=req.text, file_wave=req.output_path)
            tr = transcribe_audio(TranscribeRequest(audio_path=req.output_path))
            return {"success": True, "engine": "F5-TTS Voice Clone", "durationSec": get_audio_duration(req.output_path), "captions": tr.get("captions", [])}
        except ImportError:
            pass

    import edge_tts
    communicate = edge_tts.Communicate(req.text, "fa-IR-FaridNeural")
    await communicate.save(req.output_path)
    tr = transcribe_audio(TranscribeRequest(audio_path=req.output_path))
    return {"success": True, "engine": "Local Neural Persian TTS (Farid)", "durationSec": get_audio_duration(req.output_path), "captions": tr.get("captions", [])}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=5005)
